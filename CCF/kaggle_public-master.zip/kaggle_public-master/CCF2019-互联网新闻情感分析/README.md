思路：

直接bert梭哈，如果显存不够可以改maxlen和batachsize

也可以不同maxlen和batchsize的bert结果进行平均，会有收益。
