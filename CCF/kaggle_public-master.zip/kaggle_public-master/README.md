# 开源说明

- 互联网金融新实体发现：https://www.datafountain.cn/competitions/361/ranking

  开源第五名0.20492665分数代码

- 互联网新闻情感分析：https://www.datafountain.cn/competitions/350
  
  开源第五名0.80081755分数代码
  
- 视频版权检测算法：https://www.datafountain.cn/competitions/354/

  开源分数0.0001分数代码
  
欢迎star，欢迎关注我的知乎：https://www.zhihu.com/people/finlayliu/
